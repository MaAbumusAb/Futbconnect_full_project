from kivy.app import App
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.screenmanager import ScreenManager, Screen
from kivy.properties import StringProperty, ListProperty

class LoginScreen(Screen):
    def do_login(self, login_text, password_text):
        if login_text == 'user' and password_text == 'pass':
            self.manager.current = 'main_screen'

class MainScreen(Screen): pass

class ChatsTab(BoxLayout):
    mock_messages = ListProperty([
        {'sender': 'me', 'text': 'Hey, are you going to the lecture?'},
        {'sender': 'friend', 'text': 'Yeah, I am on my way now.'},
        {'sender': 'me', 'text': 'Great! See you there.'},
        {'sender': 'friend', 'text': "Don't forget to bring your notes."},
        {'sender': 'me', 'text': "I won't. Almost at the hall."},
        {'sender': 'friend', 'text': "Okay, I've saved you a seat."},
    ])

class GroupsTab(BoxLayout):
    mock_groups = ListProperty([
        {'name': 'CSC 501 Final Year Projects'},
        {'name': 'University Football Team'},
        {'name': 'Mobile App Devs Club'},
    ])

class ProfileTab(BoxLayout):
    name = StringProperty('Ada Lovelace')
    email = StringProperty('ada.l@futb.edu')
    department = StringProperty('Computer Science')
    role = StringProperty('Student')

class FUTBConnectApp(App):
    def build(self):
        sm = ScreenManager()
        sm.add_widget(LoginScreen(name='login_screen'))
        sm.add_widget(MainScreen(name='main_screen'))
        return sm

if __name__ == '__main__':
    FUTBConnectApp().run()
